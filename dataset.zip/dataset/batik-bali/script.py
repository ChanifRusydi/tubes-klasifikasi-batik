import PIL
from PIL import Image
import os


#check img size in current directory
for file in os.listdir():
    if file.endswith(".jpg"):
        # print(file)
        img = Image.open(file)
        print(file,img.size)